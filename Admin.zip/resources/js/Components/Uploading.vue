<template>
<div class="my-auto text-blue-600">
    <svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 24 24">
        <mask id="lineMdCloudAltUploadFilledLoop0">
            <g fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                <path stroke-dasharray="64" stroke-dashoffset="64" d="M7 19h11c2.21 0 4 -1.79 4 -4c0 -2.21 -1.79 -4 -4 -4h-1v-1c0 -2.76 -2.24 -5 -5 -5c-2.42 0 -4.44 1.72 -4.9 4h-0.1c-2.76 0 -5 2.24 -5 5c0 2.76 2.24 5 5 5Z">
                    <animate fill="freeze" attributeName="stroke-dashoffset" dur="0.15s" values="64;0" />
                    <set fill="freeze" attributeName="opacity" begin="0.175s" to="0" />
                </path>
                <g fill="#fff" stroke="none" opacity="0">
                    <circle cx="12" cy="10" r="6">
                        <animate attributeName="cx" begin="0.175s" dur="7.5s" repeatCount="indefinite" values="12;11;12;13;12" />
                    </circle>
                    <rect width="9" height="8" x="8" y="12" />
                    <rect width="15" height="12" x="1" y="8" rx="6">
                        <animate attributeName="x" begin="0.175s" dur="5.25s" repeatCount="indefinite" values="1;0;1;2;1" />
                    </rect>
                    <rect width="13" height="10" x="10" y="10" rx="5">
                        <animate attributeName="x" begin="0.175s" dur="4.25s" repeatCount="indefinite" values="10;9;10;11;10" />
                    </rect>
                    <set fill="freeze" attributeName="opacity" begin="0.175s" to="1" />
                </g>
                <g fill="#000" fill-opacity="0" stroke="none">
                    <circle cx="12" cy="10" r="4">
                        <animate attributeName="cx" begin="0.175s" dur="7.5s" repeatCount="indefinite" values="12;11;12;13;12" />
                    </circle>
                    <rect width="9" height="6" x="8" y="12" />
                    <rect width="11" height="8" x="3" y="10" rx="4">
                        <animate attributeName="x" begin="0.175s" dur="5.25s" repeatCount="indefinite" values="3;2;3;4;3" />
                    </rect>
                    <rect width="9" height="6" x="12" y="12" rx="3">
                        <animate attributeName="x" begin="0.175s" dur="4.25s" repeatCount="indefinite" values="12;11;12;13;12" />
                    </rect>
                    <set fill="freeze" attributeName="fill-opacity" begin="0.175s" to="1" />
                    <animate fill="freeze" attributeName="opacity" begin="0.175s" dur="0.125s" values="1;0" />
                </g>
                <g fill="#000" stroke="none">
                    <path d="M10 17h4v0h-4z">
                        <animate fill="freeze" attributeName="d" begin="0.325s" dur="0.05s" values="M10 17h4v0h-4z;M10 17h4v-5h-4z" />
                    </path>
                    <path d="M7 13h10l-5 0z">
                        <animate fill="freeze" attributeName="d" begin="0.375s" dur="0.025s" values="M7 13h10l-5 0z;M7 13h10l-5 -5z" />
                        <animateMotion begin="0.4s" calcMode="linear" dur="0.375s" keyPoints="0;0.25;0.5;0.75;1" keyTimes="0;0.1;0.5;0.8;1" path="M0 0v-1v2z" repeatCount="indefinite" />
                    </path>
                </g>
            </g>
        </mask>
        <rect width="24" height="24" fill="currentColor" mask="url(#lineMdCloudAltUploadFilledLoop0)" />
    </svg>
    <p class="text-3xl font-bold font-sans">uploading......</p>
</div>
</template>